import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface TooltipProps {
  children: React.ReactNode;
  text: string;
  isDarkMode: boolean;
}

export const AppTooltip = ({ children, text, isDarkMode }: TooltipProps) => {
  const [show, setShow] = useState(false);
  return (
    <div className="relative inline-block" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      <AnimatePresence>
        {show && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className={cn(
              "absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest whitespace-nowrap z-[100] shadow-xl pointer-events-none border",
              isDarkMode ? "bg-slate-900 text-white border-white/10" : "bg-white text-slate-900 border-gray-100"
            )}
          >
            {text}
            <div className={cn(
              "absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent",
              isDarkMode ? "border-t-slate-900" : "border-t-white"
            )} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

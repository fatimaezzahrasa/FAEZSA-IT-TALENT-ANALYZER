import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Users, 
  Target, 
  Plus, 
  Trash2, 
  ExternalLink, 
  Zap, 
  Search,
  LayoutDashboard,
  FileSearch,
  ArrowRight,
  Filter,
  SortAsc,
  SortDesc,
  X
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { Mission, HistoryItem } from '../types';
import { AppTooltip } from './Tooltip';

interface DashboardViewProps {
  missions: Mission[];
  history: HistoryItem[];
  isDarkMode: boolean;
  onAnalyze: () => void;
  onLoadFromHistory: (item: HistoryItem) => void;
  onCreateMission: (title: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ 
  missions, 
  history, 
  isDarkMode, 
  onAnalyze,
  onLoadFromHistory,
  onCreateMission 
}) => {
  const stats = [
    { label: 'Active Missions', value: missions.length, icon: <Target className="w-5 h-5" />, color: 'bg-indigo-600' },
    { label: 'Profiles Analyzed', value: history.length, icon: <Zap className="w-5 h-5" />, color: 'bg-blue-600' },
    { label: 'Qualified Pipeline', value: missions.reduce((acc, m) => acc + m.candidates.length, 0), icon: <Users className="w-5 h-5" />, color: 'bg-indigo-500' },
    { label: 'Avg. Match Rate', value: history.length ? `${Math.round(history.reduce((acc, h) => acc + h.matchScore, 0) / history.length)}%` : '0%', icon: <BarChart3 className="w-5 h-5" />, color: 'bg-blue-500' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className={cn(
            "p-6 rounded-3xl border flex items-center gap-4",
            isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm shadow-blue-100/50"
          )}>
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg", stat.color)}>
              {stat.icon}
            </div>
            <div>
              <p className="text-xs text-blue-400 uppercase tracking-widest font-bold">{stat.label}</p>
              <p className="text-2xl font-bold tracking-tight text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className={cn(
          "lg:col-span-2 p-8 rounded-3xl border",
          isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm"
        )}>
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold flex items-center gap-2 text-indigo-600">
              <BarChart3 className="w-5 h-5" />
              Active Pipeline Overview
            </h3>
            <AppTooltip text="Analyze new profile" isDarkMode={isDarkMode}>
              <button 
                onClick={onAnalyze}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20"
              >
                Quick Analyze <ArrowRight className="w-4 h-4" />
              </button>
            </AppTooltip>
          </div>
          
          <div className="space-y-4">
            {missions.length > 0 ? (
              missions.map(mission => (
                <div key={mission.id} className={cn(
                  "p-4 rounded-2xl border flex items-center justify-between group",
                  isDarkMode ? "bg-white/5 border-white/5 hover:bg-white/10" : "bg-blue-50/30 border-blue-50 hover:bg-blue-50 hover:border-blue-100 transition-all"
                )}>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500">
                      <Target className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">{mission.title}</h4>
                      <p className="text-xs text-blue-400">{mission.candidates.length} candidates in pipeline</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {/* Tiny pipeline visual */}
                    <div className="flex gap-1">
                      {[1, 2, 3, 4].map(s => (
                        <div key={s} className="w-1.5 h-4 bg-indigo-500/20 rounded-full" />
                      ))}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-blue-300 italic">
                <p>No active missions yet.</p>
                <button 
                  onClick={() => onCreateMission('New Mission')}
                  className="text-indigo-500 text-sm font-bold mt-2 hover:underline"
                >
                  + Create First Mission
                </button>
              </div>
            )}
          </div>
        </div>

        <div className={cn(
          "p-8 rounded-3xl border",
          isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm"
        )}>
          <h3 className="text-xl font-bold mb-8 text-indigo-600">Recent Analyses</h3>
          <div className="space-y-4">
            {history.slice(0, 5).map((item) => (
              <div 
                key={item.id}
                onClick={() => onLoadFromHistory(item)}
                className={cn(
                  "p-4 rounded-xl border group transition-all cursor-pointer",
                  isDarkMode ? "hover:bg-white/5 border-white/5" : "hover:bg-indigo-50 border-gray-100 bg-gray-50/50"
                )}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className="text-[9px] text-gray-400 font-mono font-bold uppercase">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                  <span className={cn(
                    "text-[9px] font-bold px-1.5 py-0.5 rounded",
                    item.matchScore > 80 ? "bg-green-500/10 text-green-500" : 
                    item.matchScore > 50 ? "bg-indigo-500/10 text-indigo-500" : "bg-red-500/10 text-red-500"
                  )}>
                    {item.matchScore}%
                  </span>
                </div>
                <h4 className="font-bold text-xs truncate group-hover:text-indigo-600 transition-colors">{item.candidateName}</h4>
                <p className="text-[10px] text-gray-500 truncate">{item.jobTitle}</p>
              </div>
            ))}
            {history.length === 0 && (
              <p className="text-center py-6 text-gray-500 text-xs italic">No analyses yet.</p>
            )}
          </div>
          
          {history.length > 5 && (
            <button 
              onClick={onAnalyze}
              className="w-full mt-4 py-2 text-[10px] font-bold uppercase tracking-widest text-indigo-500 hover:bg-indigo-500/5 rounded-lg transition-all"
            >
              View Full History
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

interface MissionsViewProps {
  missions: Mission[];
  selectedMission: Mission | null;
  onSelectMission: (m: Mission) => void;
  onCreateMission: (title: string) => void;
  onDeleteMission: (id: string) => void;
  onUpdateCandidateStage: (missionId: string, candidateId: string, stage: string) => void;
  isDarkMode: boolean;
  onStartAnalysis: () => void;
}

export const MissionsView: React.FC<MissionsViewProps> = ({
  missions,
  selectedMission,
  onSelectMission,
  onCreateMission,
  onDeleteMission,
  onUpdateCandidateStage,
  isDarkMode,
  onStartAnalysis
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('ALL');
  const [sortConfig, setSortConfig] = useState<{ key: 'score' | 'name', direction: 'asc' | 'desc' }>({ key: 'score', direction: 'desc' });
  
  const stages = ['SOURCED', 'ANALYZED', 'SHORTLISTED', 'INTERVIEWED', 'REJECTED'];

  const filteredAndSortedCandidates = useMemo(() => {
    if (!selectedMission) return [];

    let result = [...selectedMission.candidates];

    // Filter by search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(c => 
        c.candidateName.toLowerCase().includes(q) || 
        c.jobTitle.toLowerCase().includes(q)
      );
    }

    // Filter by stage
    if (stageFilter !== 'ALL') {
      result = result.filter(c => (c.pipelineStage || 'ANALYZED') === stageFilter);
    }

    // Sort
    result.sort((a, b) => {
      if (sortConfig.key === 'score') {
        return sortConfig.direction === 'asc' ? a.matchScore - b.matchScore : b.matchScore - a.matchScore;
      } else {
        const nameA = a.candidateName.toLowerCase();
        const nameB = b.candidateName.toLowerCase();
        if (sortConfig.direction === 'asc') return nameA < nameB ? -1 : 1;
        return nameA > nameB ? -1 : 1;
      }
    });

    return result;
  }, [selectedMission, searchQuery, stageFilter, sortConfig]);

  const toggleSort = (key: 'score' | 'name') => {
    if (sortConfig.key === key) {
      setSortConfig({ key, direction: sortConfig.direction === 'asc' ? 'desc' : 'asc' });
    } else {
      setSortConfig({ key, direction: 'desc' });
    }
  };

  return (
    <div className="flex gap-8 h-[calc(100vh-200px)]">
      {/* Sidebar - Mission List */}
      <div className={cn(
        "w-80 border-r pr-6 space-y-4 overflow-y-auto",
        isDarkMode ? "border-white/5" : "border-blue-100"
      )}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold uppercase tracking-widest text-xs text-blue-400">Your Missions</h3>
          <AppTooltip text="Start new recruitment mission" isDarkMode={isDarkMode}>
            <button 
              onClick={() => onCreateMission(prompt('Enter Mission Title') || 'New Mission')}
              className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20"
            >
              <Plus className="w-4 h-4" />
            </button>
          </AppTooltip>
        </div>
        
        <div className="space-y-2">
          {missions.map(m => (
            <div 
              key={m.id}
              onClick={() => onSelectMission(m)}
              className={cn(
                "p-4 rounded-2xl border transition-all cursor-pointer group relative",
                selectedMission?.id === m.id 
                  ? "bg-indigo-500/10 border-indigo-400/50" 
                  : isDarkMode ? "bg-white/5 border-white/5 hover:border-white/20" : "bg-white border-blue-100 hover:border-blue-300 shadow-sm shadow-blue-50"
              )}
            >
              <h4 className={cn(
                "font-bold text-sm",
                selectedMission?.id === m.id ? "text-indigo-600" : "text-gray-700"
              )}>{m.title}</h4>
              <p className="text-[10px] text-blue-400 mt-1 uppercase font-bold tracking-tighter">{m.candidates.length} Profiles</p>
              
              <AppTooltip text="Permanently delete mission" isDarkMode={isDarkMode}>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteMission(m.id);
                  }}
                  className="absolute top-4 right-4 p-1 opacity-0 group-hover:opacity-100 text-blue-200 hover:text-red-500 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </AppTooltip>
            </div>
          ))}
        </div>
      </div>

      {/* Main Mission Detail */}
      <div className="flex-1 overflow-y-auto">
        {selectedMission ? (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">{selectedMission.title}</h2>
                <p className="text-gray-500 text-sm mt-1">Created on {new Date(selectedMission.createdAt).toLocaleDateString()}</p>
              </div>
              <button 
                onClick={onStartAnalysis}
                className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-xl shadow-indigo-500/20 active:scale-95 transition-all text-sm"
              >
                <Zap className="w-4 h-4" /> Analyze Candidates
              </button>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              <div className={cn(
                "p-8 rounded-3xl border",
                isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm"
              )}>
                <h3 className="text-sm font-bold uppercase tracking-widest text-blue-400 mb-4 flex items-center gap-2">
                  <FileSearch className="w-4 h-4" /> Job Details
                </h3>
                <div className={cn(
                  "p-4 rounded-xl font-mono text-xs whitespace-pre-wrap h-64 overflow-y-auto leading-relaxed",
                  isDarkMode ? "bg-black/40 text-gray-400" : "bg-gray-50 text-gray-500"
                )}>
                  {selectedMission.jdText || 'Set Job Description in Analyzer tab...'}
                </div>
              </div>

              <div className={cn(
                "p-8 rounded-3xl border",
                isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200"
              )}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-green-400 flex items-center gap-2">
                    <Users className="w-4 h-4" /> Candidate Pool ({selectedMission.candidates.length})
                  </h3>
                  
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative group/search">
                      <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-gray-500" />
                      <input 
                        type="text" 
                        placeholder="Search talent..."
                        className={cn(
                          "pl-8 pr-3 py-2 rounded-lg text-xs font-medium border focus:outline-none focus:ring-1 focus:ring-indigo-500 w-32 sm:w-40 transition-all",
                          isDarkMode ? "bg-black/20 border-white/10 text-gray-300" : "bg-gray-50 border-gray-100"
                        )}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      {searchQuery && (
                        <button onClick={() => setSearchQuery('')} className="absolute right-2 top-2.5">
                          <X className="w-3 h-3 text-gray-500 hover:text-indigo-400" />
                        </button>
                      )}
                    </div>

                    <select 
                      className={cn(
                        "px-2 py-2 rounded-lg text-[10px] font-bold uppercase tracking-tight border focus:outline-none",
                        isDarkMode ? "bg-black/20 border-white/10 text-gray-400" : "bg-gray-50 border-gray-100"
                      )}
                      value={stageFilter}
                      onChange={(e) => setStageFilter(e.target.value)}
                    >
                      <option value="ALL">All Stages</option>
                      {stages.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>

                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => toggleSort('score')}
                        title="Sort by Score"
                        className={cn(
                          "p-2 rounded-lg transition-all border",
                          sortConfig.key === 'score' ? "bg-indigo-600 text-white border-indigo-500" : (isDarkMode ? "bg-white/5 border-white/5 text-gray-400" : "bg-gray-50 border-gray-100 text-gray-500")
                        )}
                      >
                        {sortConfig.key === 'score' && sortConfig.direction === 'asc' ? <SortAsc className="w-3.5 h-3.5" /> : <SortDesc className="w-3.5 h-3.5" />}
                      </button>
                      <button 
                        onClick={() => toggleSort('name')}
                        title="Sort by Name"
                        className={cn(
                          "p-2 rounded-lg transition-all border",
                          sortConfig.key === 'name' ? "bg-indigo-600 text-white border-indigo-500" : (isDarkMode ? "bg-white/5 border-white/5 text-gray-400" : "bg-gray-50 border-gray-100 text-gray-500")
                        )}
                      >
                       <span className="text-[10px] font-bold px-0.5">A-Z</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 max-h-[16rem] overflow-y-auto pr-2 custom-scrollbar">
                  {filteredAndSortedCandidates.map((c, i) => (
                    <div key={i} className={cn(
                      "p-4 rounded-xl border flex items-center justify-between group transition-all",
                      isDarkMode ? "bg-white/5 border-white/5 hover:bg-white/10" : "bg-gray-50 border-gray-100 shadow-sm hover:shadow-md"
                    )}>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <p className="font-bold text-sm truncate">{c.candidateName}</p>
                          <span className={cn(
                            "text-[10px] px-2 py-0.5 rounded-full font-bold shrink-0",
                            c.matchScore > 80 ? "bg-green-500/10 text-green-500" : 
                            c.matchScore > 60 ? "bg-amber-500/10 text-amber-500" : "bg-red-500/10 text-red-500"
                          )}>
                            {c.matchScore}%
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                          <div className="flex-1 h-1 bg-gray-200/20 rounded-full overflow-hidden max-w-[80px]">
                            <div 
                              className={cn(
                                "h-full transition-all duration-1000",
                                c.matchScore > 80 ? "bg-green-500" : 
                                c.matchScore > 60 ? "bg-amber-500" : "bg-red-500"
                              )}
                              style={{ width: `${c.matchScore}%` }}
                            />
                          </div>
                          <div className="flex items-center gap-1.5 min-w-[100px]">
                            <div className={cn(
                              "w-1.5 h-1.5 rounded-full shrink-0",
                              c.pipelineStage === 'REJECTED' ? "bg-red-500" : 
                              c.pipelineStage === 'SHORTLISTED' ? "bg-indigo-500" :
                              c.pipelineStage === 'INTERVIEWED' ? "bg-green-500" : "bg-blue-400"
                            )} />
                            <AppTooltip text="Change candidate stage" isDarkMode={isDarkMode}>
                              <select 
                                value={c.pipelineStage || 'ANALYZED'}
                                onChange={(e) => onUpdateCandidateStage(selectedMission.id, c.id, e.target.value)}
                                className="text-[9px] bg-transparent text-gray-500 uppercase font-bold focus:outline-none cursor-pointer hover:text-indigo-400 transition-colors w-full"
                              >
                                {stages.map(s => <option key={s} value={s} className="bg-slate-900">{s}</option>)}
                              </select>
                            </AppTooltip>
                          </div>
                        </div>
                      </div>
                        <AppTooltip text="View full candidate profile" isDarkMode={isDarkMode}>
                          <button className="p-2 text-gray-400 hover:text-indigo-400 transition-colors">
                            <ExternalLink className="w-4 h-4" />
                          </button>
                        </AppTooltip>
                    </div>
                  ))}
                  {filteredAndSortedCandidates.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <p>{selectedMission.candidates.length === 0 ? 'Pipeline is currently empty.' : 'No candidates match your filters.'}</p>
                      {selectedMission.candidates.length === 0 ? (
                        <button onClick={onStartAnalysis} className="text-xs font-bold text-blue-400 underline mt-1">
                          Start Screening
                        </button>
                      ) : (
                        <button 
                          onClick={() => { setSearchQuery(''); setStageFilter('ALL'); }}
                          className="text-xs font-bold text-indigo-500 underline mt-1"
                        >
                          Clear Filters
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Pipeline Visualization */}
            <div className="grid lg:grid-cols-2 gap-8">
              <div className={cn(
                "p-8 rounded-3xl border",
                isDarkMode ? "bg-blue-900/10 border-blue-800/20" : "bg-white border-blue-100 shadow-sm shadow-blue-50/50"
              )}>
                <h3 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-2 text-blue-400">
                  <Zap className="w-4 h-4" /> Selection Criteria
                </h3>
                <div className="space-y-3">
                  {selectedMission.criteria.length > 0 ? (
                    selectedMission.criteria.map((cr, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-sm text-gray-400">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                        {cr}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-gray-500 italic">No specific criteria added. AI will use JD text for evaluation.</p>
                  )}
                  <button 
                    onClick={() => {
                      const newVal = prompt('Enter a new choice criterion (e.g. "Min 5 years React"):');
                      if (newVal) {
                        // In a real app we'd pass an updateMission function
                        alert('In a full version, this would save to the mission.');
                      }
                    }}
                    className="text-[10px] uppercase font-bold text-indigo-500 mt-4 hover:underline"
                  >
                    + Add Criterion
                  </button>
                </div>
              </div>

              <div className={cn(
                "p-8 rounded-3xl border",
                isDarkMode ? "bg-blue-900/10 border-blue-800/20" : "bg-white border-blue-100 shadow-sm shadow-blue-50/50"
              )}>
                <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-blue-400">Talent Pipeline Status</h3>
                <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                  {['SOURCED', 'ANALYZED', 'SHORTLISTED', 'INTERVIEWED', 'REJECTED'].map(stage => {
                    const stageCand = selectedMission.candidates.filter(c => (c.pipelineStage || 'ANALYZED') === stage);
                    return (
                      <div key={stage} className="space-y-3">
                        <div className="flex items-center justify-between px-2">
                          <span className="text-[10px] font-bold text-gray-500">{stage}</span>
                          <span className="text-[10px] bg-gray-500/10 px-2 py-0.5 rounded-full">{stageCand.length}</span>
                        </div>
                        <div className="h-1.5 bg-gray-500/10 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-indigo-500 transition-all duration-1000" 
                            style={{ width: `${(stageCand.length / (selectedMission.candidates.length || 1)) * 100}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-6">
            <div className="w-20 h-20 bg-indigo-500/10 rounded-full flex items-center justify-center text-indigo-400 shadow-2xl shadow-blue-100/50">
              <Zap className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-indigo-600">Select a Mission</h3>
              <p className="text-blue-400 max-w-sm mt-3 opacity-60">Choose an existing mission from the sidebar or create a new one to begin managing your recruitment pipeline.</p>
            </div>
            <button 
              onClick={() => onCreateMission(prompt('Enter Mission Title') || 'New Mission')}
              className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 active:scale-95 transition-all"
            >
              Start New Mission
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

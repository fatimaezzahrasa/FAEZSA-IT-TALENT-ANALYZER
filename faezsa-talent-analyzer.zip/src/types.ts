export interface AnalysisResult {
  id: string;
  timestamp: number;
  jobTitle: string;
  candidateName: string;
  matchScore: number;
  itDomain: string;
  sourceJd: string;
  sourceCandidate: string;
  summary: string;
  strongMatches: string[];
  missingImportant: string[];
  redFlags: string[];
  plusPoints: string[];
  flouPoints: { question: string; reason: string }[];
  hiddenStack: string[];
  interviewQuestions: string[];
  salaryBenchmark: string;
  booleanString: string;
  skillsRadar: {
    labels: string[];
    candidate: number[];
    market: number[];
  };
  pipelineStage?: 'Sourced' | 'Analyzed' | 'Shortlisted' | 'Interviewed' | 'Rejected';
}

export interface Mission {
  id: string;
  title: string;
  jdText: string;
  criteria: string[];
  status: 'Open' | 'Closed' | 'Draft';
  createdAt: number;
  candidates: AnalysisResult[];
}

export interface HistoryItem {
  id: string;
  jobTitle: string;
  candidateName: string;
  matchScore: number;
  timestamp: number;
  result: AnalysisResult;
}

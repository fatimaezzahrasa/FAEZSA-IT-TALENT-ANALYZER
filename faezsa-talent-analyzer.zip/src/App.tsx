/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  History, 
  LogIn, 
  LogOut, 
  User, 
  Zap, 
  Download, 
  Trash2, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  MessageSquare, 
  Brain, 
  Copy, 
  ExternalLink,
  Mic,
  Moon,
  Sun,
  FileSearch,
  LayoutDashboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { AppTooltip } from './components/Tooltip';
import { 
  Chart as ChartJS, 
  RadialLinearScale, 
  PointElement, 
  LineElement, 
  Filler, 
  Tooltip, 
  Legend 
} from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { DashboardView, MissionsView } from './components/MissionComponents';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer
} from 'recharts';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

import { cn } from './lib/utils';
import { parseFile } from './lib/parsers';
import { analyzeTalent, extractJdMetadata, JdMetadata } from './lib/gemini';
import { AnalysisResult, HistoryItem, Mission } from './types';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

// Constants
const DEMO_USER = { email: 'demo@talent.com', password: 'demo123' };

// Custom component for highlighted text areas
const HighlightedTextArea = ({ 
  value, 
  onChange, 
  onKeyDown,
  placeholder, 
  isDarkMode, 
  className,
  height = "h-64"
}: { 
  value: string; 
  onChange: (val: string) => void;
  onKeyDown?: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
  isDarkMode: boolean;
  className?: string;
  height?: string;
}) => {
  const overlayRef = React.useRef<HTMLDivElement>(null);
  
  const SKILLS = [
    'Python', 'Java', 'JavaScript', 'React', 'AWS', 'Docker', 'Kubernetes', 'SQL', 
    'MongoDB', 'Terraform', 'GraphQL', 'Node.js', 'TypeScript', 'Django', 
    'Spring Boot', 'Angular', 'Vue', 'Azure', 'GCP', 'Jenkins', 'Git', 'Linux', 
    'Redis', 'Kafka', 'System Design', 'Microservices', 'Unit Testing', 'Express',
    'Tailwind', 'Next.js', 'FastAPI', 'Flask', 'PostgreSQL', 'Elasticsearch',
    'C++', 'Golang', 'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Flutter'
  ];

  const RECRUITMENT_TERMS = [
    'Bachelor', 'Master', 'Degree', 'Experience', 'Requirement', 'Responsibility',
    'Senior', 'Junior', 'Mid-level', 'Leading', 'Develop', 'Engineer', 'Architect',
    'Knowledge', 'Proficient', 'Familiarity', 'Remote', 'Hybrid', 'Contract',
    'Full-time', 'Permanent', 'Agile', 'Scrum', 'Stakeholder', 'Collaborate',
    'Communication', 'Analytical', 'Problem-solving'
  ];

  const ALL_KEYWORDS = [...SKILLS, ...RECRUITMENT_TERMS];

  const getHighlightedText = (text: string) => {
    if (!text) return null;
    
    const sortedKeywords = [...ALL_KEYWORDS].sort((a, b) => b.length - a.length);
    const pattern = new RegExp(`\\b(${sortedKeywords.join('|')})\\b`, 'gi');
    
    const parts = text.split(pattern);
    
    return parts.map((part, i) => {
      const skillMatch = SKILLS.find(k => k.toLowerCase() === part.toLowerCase());
      const termMatch = RECRUITMENT_TERMS.find(k => k.toLowerCase() === part.toLowerCase());
      
      if (skillMatch) {
        return (
          <span 
            key={i} 
            className={cn(
              "font-bold underline decoration-indigo-500/30",
              isDarkMode ? "text-indigo-400" : "text-indigo-600"
            )}
          >
            {part}
          </span>
        );
      } else if (termMatch) {
        return (
          <span 
            key={i} 
            className={cn(
              "font-medium italic",
              isDarkMode ? "text-amber-400" : "text-amber-600"
            )}
          >
            {part}
          </span>
        );
      }
      return part;
    });
  };

  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (overlayRef.current) {
      overlayRef.current.scrollTop = e.currentTarget.scrollTop;
      overlayRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  return (
    <div className={cn("relative group w-full overflow-hidden rounded-xl border", isDarkMode ? "bg-black/20 border-white/10" : "bg-white border-gray-200", height)}>
      {/* Highlighting Overlay - rendered behind */}
      <div 
        ref={overlayRef}
        className={cn(
          "absolute inset-0 p-4 pointer-events-none whitespace-pre-wrap break-words overflow-hidden",
          "font-mono text-sm leading-relaxed",
          isDarkMode ? "text-gray-400/50" : "text-gray-500/50"
        )}
      >
        {getHighlightedText(value)}
        {/* Placeholder if empty */}
        {(!value || value === '') && (
           <span className="opacity-40 italic">{placeholder}</span>
        )}
      </div>
      
      {/* Real Textarea */}
      <textarea
        className={cn(
          "w-full h-full p-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none transition-all",
          "font-mono text-sm leading-relaxed bg-transparent relative z-10",
          "caret-indigo-500 text-transparent",
          isDarkMode ? "selection:bg-indigo-500/30" : "selection:bg-indigo-100",
          className
        )}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKeyDown}
        onScroll={handleScroll}
        spellCheck={false}
      />
    </div>
  );
};

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [jdText, setJdText] = useState('');
  const [candidateText, setCandidateText] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'MISSIONS' | 'ANALYZER'>('DASHBOARD');
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [showQuickCompare, setShowQuickCompare] = useState(false);
  const [compareSelection, setCompareSelection] = useState<{ id1: string; id2: string }>({ id1: '', id2: '' });
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyPrompt, setShowApiKeyPrompt] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [jdMetadata, setJdMetadata] = useState<JdMetadata | null>(null);
  const [isExtractingMetadata, setIsExtractingMetadata] = useState(false);

  // Load history and session on mount
  useEffect(() => {
    const savedSession = localStorage.getItem('talent_analyzer_session');
    if (savedSession) setIsLoggedIn(true);

    const savedHistory = localStorage.getItem('talent_analyzer_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));

    const savedMissions = localStorage.getItem('talent_analyzer_missions');
    if (savedMissions) setMissions(JSON.parse(savedMissions));

    const savedTheme = localStorage.getItem('talent_analyzer_theme');
    if (savedTheme) setIsDarkMode(savedTheme === 'dark');

    const savedApiKey = localStorage.getItem('talent_analyzer_api_key');
    if (savedApiKey) {
      setApiKey(savedApiKey);
    } else {
      setShowApiKeyPrompt(true);
    }
  }, []);

  const saveApiKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem('talent_analyzer_api_key', key);
    setShowApiKeyPrompt(false);
  };

  useEffect(() => {
    localStorage.setItem('talent_analyzer_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('talent_analyzer_missions', JSON.stringify(missions));
  }, [missions]);

  useEffect(() => {
    localStorage.setItem('talent_analyzer_theme', isDarkMode ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);

  // Automatic JD Extraction logic
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (jdText && jdText.trim().length > 20) {
        setIsExtractingMetadata(true);
        try {
          const metadata = await extractJdMetadata(jdText, apiKey);
          setJdMetadata(metadata);
        } catch (err) {
          console.error("Auto extraction error", err);
        } finally {
          setIsExtractingMetadata(false);
        }
      } else {
        setJdMetadata(null);
      }
    }, 1500); // Debounce 1.5s

    return () => clearTimeout(timeoutId);
  }, [jdText, apiKey]);

  // Handlers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginForm.email === DEMO_USER.email && loginForm.password === DEMO_USER.password) {
      setIsLoggedIn(true);
      localStorage.setItem('talent_analyzer_session', 'active');
      setError(null);
    } else {
      setError('Invalid credentials. Use demo@talent.com / demo123');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('talent_analyzer_session');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'jd' | 'candidate') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const text = await parseFile(file);
      if (target === 'jd') setJdText(text);
      else setCandidateText(text);
    } catch (err) {
      setError(`Failed to parse file: ${err}`);
    } finally {
      setIsLoading(false);
    }
  };

  const resetAnalysis = () => {
    setResult(null);
    setCandidateText('');
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!jdText.trim() || !candidateText.trim()) {
      setError('Please provide both Job Description and Candidate Profile.');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const finalJD = jdText || selectedMission?.jdText || '';
      if (!finalJD || !candidateText) {
        throw new Error('Please provide both Job Description and Candidate Profile');
      }
      const analysis = await analyzeTalent(finalJD, candidateText, apiKey);
      setResult(analysis);
      
      const newItem: HistoryItem = {
        id: analysis.id,
        jobTitle: analysis.jobTitle,
        candidateName: analysis.candidateName,
        matchScore: analysis.matchScore,
        timestamp: analysis.timestamp,
        result: analysis
      };
      setHistory(prev => [newItem, ...prev]);

      // Update mission if selected
      if (selectedMission) {
        setMissions(prev => prev.map(m => 
          m.id === selectedMission.id 
            ? { ...m, candidates: [analysis, ...m.candidates] }
            : m
        ));
      }

      if (analysis.matchScore > 85) {
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FFD700', '#0000FF', '#FFFFFF']
        });
      }
    } catch (err) {
      setError(`Analysis failed: ${err}`);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadFromHistory = (item: HistoryItem) => {
    setResult(item.result);
    setJdText(item.result.sourceJd || ''); 
    setCandidateText(item.result.sourceCandidate || '');
    setShowHistory(false);
    setActiveTab('ANALYZER');
  };

  const deleteHistoryItem = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const exportCSV = () => {
    if (!result) return;
    const rows = [
      ['Category', 'Value'],
      ['Candidate Name', result.candidateName],
      ['Job Title', result.jobTitle],
      ['Match Score', `${result.matchScore}%`],
      ['IT Domain', result.itDomain],
      ['Strong Matches', result.strongMatches.join('; ')],
      ['Missing Important', result.missingImportant.join('; ')],
      ['Salary Benchmark', result.salaryBenchmark]
    ];
    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Analysis_${result.candidateName}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const scheduleInterview = () => {
    if (!result) return;
    const body = `Hi ${result.candidateName},\n\nI'd like to schedule an interview for the ${result.jobTitle} position.\n\nBest regards,\nRecruitment Team`;
    window.location.href = `mailto:?subject=Interview: ${result.jobTitle}&body=${encodeURIComponent(body)}`;
  };

  const downloadPDF = () => {
    if (!result) return;
    const doc = new jsPDF();
    
    doc.setFontSize(20);
    doc.text('FAEZSA Talent Analyzer Report', 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Job Title: ${result.jobTitle}`, 20, 35);
    doc.text(`Candidate: ${result.candidateName}`, 20, 42);
    doc.text(`Match Score: ${result.matchScore}%`, 20, 49);
    doc.text(`IT Domain: ${result.itDomain}`, 20, 56);
    
    doc.text('Summary:', 20, 70);
    doc.setFontSize(10);
    doc.text(result.summary, 20, 77, { maxWidth: 170 });

    autoTable(doc, {
      startY: 100,
      head: [['Category', 'Details']],
      body: [
        ['Strong Matches', result.strongMatches.join(', ')],
        ['Missing Important', result.missingImportant.join(', ')],
        ['Red Flags', result.redFlags.join(', ')],
        ['Interview Questions', result.interviewQuestions.join('\n')],
        ['Salary Benchmark', result.salaryBenchmark]
      ],
    });

    doc.save(`Talent_Analysis_${result.candidateName.replace(/\s+/g, '_')}.pdf`);
  };

  const openDeepSearch = () => {
    if (!result) return;
    const skills = result.strongMatches.slice(0, 3).join(' ');
    const queries = [
      `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(skills)}`,
      `https://www.google.com/search?q=site:linkedin.com/in/+"${encodeURIComponent(skills)}"`,
      `https://www.upwork.com/search/profiles/?q=${encodeURIComponent(skills)}`
    ];
    queries.forEach(url => window.open(url, '_blank'));
  };

  const startVoiceInput = (target: 'jd' | 'candidate') => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser.');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (target === 'jd') setJdText(prev => prev + ' ' + transcript);
      else setCandidateText(prev => prev + ' ' + transcript);
    };
    recognition.start();
  };

  const createMission = () => {
    const newMission: Mission = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Recruitment Mission',
      jdText: '',
      criteria: [],
      status: 'Open',
      createdAt: Date.now(),
      candidates: []
    };
    setMissions(prev => [newMission, ...prev]);
    setSelectedMission(newMission);
    setActiveTab('MISSIONS');
  };

  const deleteMission = (id: string) => {
    setMissions(prev => prev.filter(m => m.id !== id));
    if (selectedMission?.id === id) setSelectedMission(null);
  };

  const updateCandidateStage = (missionId: string, candidateId: string, stage: string) => {
    setMissions(prev => prev.map(m => {
      if (m.id === missionId) {
        return {
          ...m,
          candidates: m.candidates.map(c => 
            c.id === candidateId ? { ...c, pipelineStage: stage as any } : c
          )
        };
      }
      return m;
    }));
    
    setHistory(prev => prev.map(h => 
      h.id === candidateId ? { ...h, result: { ...h.result, pipelineStage: stage as any } } : h
    ));

    if (selectedMission?.id === missionId) {
      setSelectedMission(prev => {
        if (!prev) return null;
        return {
          ...prev,
          candidates: prev.candidates.map(c => 
            c.id === candidateId ? { ...c, pipelineStage: stage as any } : c
          )
        };
      });
    }
  };

  // Views
  if (!isLoggedIn) {
    return (
      <div className={cn(
        "min-h-screen flex items-center justify-center p-4 transition-colors duration-500",
        isDarkMode ? "bg-slate-950 text-white" : "bg-slate-50 text-slate-900"
      )}>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn(
            "w-full max-w-md p-8 rounded-3xl shadow-2xl backdrop-blur-xl border",
            isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
          )}
        >
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/40">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-indigo-600">FAEZSA</h1>
            <p className="text-gray-500 font-medium tracking-wide">Talent Analyzer Pro</p>
            <div className="mt-2 text-[10px] uppercase font-bold tracking-[0.2em] text-gray-400">
               Professional IT Recruitment Intelligence
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700">Email Address</label>
              <div className="relative">
                <LogIn className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input 
                  type="email"
                  required
                  placeholder="demo@talent.com"
                  className={cn(
                    "w-full pl-10 pr-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all",
                    isDarkMode ? "bg-black/20 border-white/10 text-gray-200" : "bg-gray-50 border-gray-200 text-gray-800"
                  )}
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700">Password</label>
              <div className="relative">
                <Zap className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input 
                  type="password"
                  required
                  placeholder="••••••••"
                  className={cn(
                    "w-full pl-10 pr-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all",
                    isDarkMode ? "bg-black/20 border-white/10 text-gray-200" : "bg-gray-50 border-gray-200 text-gray-800"
                  )}
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                />
              </div>
            </div>
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="text-red-400 text-sm flex items-center gap-2"
              >
                <AlertTriangle className="w-4 h-4" />
                {error}
              </motion.div>
            )}
            <button 
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-indigo-500/20 transition-all active:scale-[0.98]"
            >
              Sign In
            </button>
          </form>

          <p className="mt-8 text-center text-xs text-gray-500">
            Internal IT Personnel Only. &copy; 2026 FAEZSA Corp.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={cn(
      "min-h-screen transition-colors duration-500 font-sans selection:bg-indigo-500/30",
      isDarkMode ? "bg-[#0a0e27] text-white" : "bg-slate-50 text-gray-900"
    )}>
      {/* Navigation */}
      <nav className={cn(
        "sticky top-0 z-50 backdrop-blur-md border-b flex items-center justify-between px-6 py-4",
        isDarkMode ? "bg-[#0a0e27]/80 border-white/5 shadow-lg shadow-black/20" : "bg-white/80 border-gray-200 shadow-sm"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white text-xl shadow-[0_0_20px_rgba(79,70,229,0.3)]">
            <Zap className="w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-xl tracking-tight uppercase text-indigo-500">
              FAEZSA <span className="font-light opacity-60">Talent Analyzer</span>
            </span>
            <span className="text-[9px] uppercase font-bold tracking-[0.1em] text-gray-400">
              Professional IT Recruitment Intelligence
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
            <AppTooltip text="Mission Overview" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setActiveTab('DASHBOARD')}
                className={cn(
                  "px-4 py-2 rounded-lg text-[11px] font-bold uppercase tracking-widest transition-all flex items-center gap-2",
                  activeTab === 'DASHBOARD' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-gray-400 hover:text-indigo-600 hover:bg-gray-100"
                )}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                Dashboard
              </button>
            </AppTooltip>
            <AppTooltip text="Global Mission Control" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setActiveTab('MISSIONS')}
                className={cn(
                  "px-4 py-2 rounded-lg text-[11px] font-bold uppercase tracking-widest transition-all flex items-center gap-2",
                  activeTab === 'MISSIONS' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-gray-400 hover:text-indigo-600 hover:bg-gray-100"
                )}
              >
                <Plus className="w-3.5 h-3.5" />
                Missions
              </button>
            </AppTooltip>
            <AppTooltip text="Deep Talent Analysis" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setActiveTab('ANALYZER')}
                className={cn(
                  "px-4 py-2 rounded-lg text-[11px] font-bold uppercase tracking-widest transition-all flex items-center gap-2",
                  activeTab === 'ANALYZER' ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-gray-400 hover:text-indigo-600 hover:bg-gray-100"
                )}
              >
                <Zap className="w-3.5 h-3.5" />
                Quick Analyzer
              </button>
            </AppTooltip>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <AppTooltip text={apiKey ? "AI Intelligence Engine is currently processing your data" : "Using local mock logic for analysis"} isDarkMode={isDarkMode}>
              <div className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.1em] border",
                apiKey 
                 ? "bg-green-500/10 text-green-400 border-green-500/20" 
                 : "bg-orange-500/10 text-orange-400 border-orange-500/20 shadow-[0_0_10px_rgba(249,115,22,0.1)]"
              )}>
                 <span className={cn(
                   "w-1.5 h-1.5 rounded-full",
                   apiKey ? "bg-green-400 animate-pulse" : "bg-orange-400"
                 )}></span> 
                 {apiKey ? "Intelligence Engine Active" : "Local Logic Mode (Mock)"}
              </div>
            </AppTooltip>
          </div>
          <div className="flex items-center gap-2">
            <AppTooltip text="Quick Profile Compare" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setShowQuickCompare(true)}
                className={cn(
                  "p-2 rounded-lg transition-colors",
                  isDarkMode ? "hover:bg-white/5" : "hover:bg-gray-100"
                )}
              >
                <Search className="w-5 h-5 text-indigo-400" />
              </button>
            </AppTooltip>
            <AppTooltip text="Intelligence Settings" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setShowApiKeyPrompt(true)}
                className={cn(
                  "p-2 rounded-lg transition-colors",
                  isDarkMode ? "hover:bg-white/5" : "hover:bg-gray-100"
                )}
              >
                <Zap className={cn("w-5 h-5", apiKey ? "text-yellow-500" : "text-gray-500")} />
              </button>
            </AppTooltip>
            <AppTooltip text={isDarkMode ? "Light Mode" : "Dark Mode"} isDarkMode={isDarkMode}>
              <button 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={cn(
                  "p-2 rounded-lg transition-colors border-l border-white/5 pl-4",
                  isDarkMode ? "hover:bg-white/5" : "hover:bg-gray-100"
                )}
              >
                {isDarkMode ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-indigo-600" />}
              </button>
            </AppTooltip>
            <AppTooltip text="Analysis History" isDarkMode={isDarkMode}>
              <button 
                onClick={() => setShowHistory(!showHistory)}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-lg transition-colors",
                  isDarkMode ? "hover:bg-white/10" : "hover:bg-gray-100"
                )}
              >
                <History className="w-5 h-5 opacity-60" />
                <span className="text-[11px] uppercase font-bold tracking-widest hidden sm:inline">History</span>
              </button>
            </AppTooltip>
            <AppTooltip text="Sign Out" isDarkMode={isDarkMode}>
              <button 
                onClick={handleLogout}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-lg transition-colors text-red-400/80 hover:text-red-400",
                  isDarkMode ? "hover:bg-red-500/10" : "hover:bg-red-50"
                )}
              >
                <LogOut className="w-5 h-5" />
              </button>
            </AppTooltip>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-6">
        {activeTab === 'DASHBOARD' && (
          <DashboardView 
            missions={missions} 
            history={history} 
            isDarkMode={isDarkMode} 
            onAnalyze={() => setActiveTab('ANALYZER')}
            onLoadFromHistory={loadFromHistory}
            onCreateMission={createMission}
          />
        )}

        {activeTab === 'MISSIONS' && (
          <MissionsView 
            missions={missions}
            selectedMission={selectedMission}
            onSelectMission={setSelectedMission}
            onCreateMission={createMission}
            onDeleteMission={deleteMission}
            onUpdateCandidateStage={updateCandidateStage}
            isDarkMode={isDarkMode}
            onStartAnalysis={() => setActiveTab('ANALYZER')}
          />
        )}

        {activeTab === 'ANALYZER' && (
          <div className="space-y-8">
            {selectedMission && (
              <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-2xl flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-indigo-400" />
                  <div>
                    <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-widest">Active Mission Analysis</span>
                    <h3 className="font-bold text-indigo-600">{selectedMission.title}</h3>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedMission(null)}
                  className="text-xs font-bold text-indigo-400 hover:text-indigo-600"
                >
                  Exit Mission Mode
                </button>
              </div>
            )}
            
            <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Job Description Input */}
          <SectionContainer title="Job Description" icon={<FileSearch className="w-5 h-5" />} isDarkMode={isDarkMode}>
            <div className="space-y-4">
              {/* Extracted Metadata Preview */}
              <AnimatePresence>
                {jdMetadata && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className={cn(
                      "p-3 rounded-xl border flex flex-col md:flex-row gap-4 text-[10px] font-bold uppercase tracking-wider",
                      isDarkMode ? "bg-indigo-500/10 border-indigo-500/20" : "bg-indigo-50 border-indigo-100"
                    )}
                  >
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="text-gray-500 text-[8px]">Extracted Title</span>
                      <span className={isDarkMode ? "text-indigo-400" : "text-indigo-600 line-clamp-1"}>{jdMetadata.jobTitle}</span>
                    </div>
                    <div className="flex-1 flex flex-col gap-1">
                      <span className="text-gray-500 text-[8px]">Experience Level</span>
                      <span className={isDarkMode ? "text-amber-400" : "text-amber-600"}>{jdMetadata.experienceLevel}</span>
                    </div>
                    <div className="flex-[2] flex flex-col gap-1">
                      <span className="text-gray-500 text-[8px]">Required Skills</span>
                      <div className="flex flex-wrap gap-1">
                        {jdMetadata.requiredSkills.map((s, i) => (
                          <span key={i} className={cn(
                            "px-1.5 py-0.5 rounded-md",
                            isDarkMode ? "bg-white/5 text-gray-300" : "bg-white text-gray-700 shadow-sm"
                          )}>{s}</span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative group">
                {isExtractingMetadata && (
                  <div className="absolute top-2 right-12 z-20 flex items-center gap-2 pointer-events-none">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></div>
                    <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-tighter">Extracting Metadata...</span>
                  </div>
                )}
                <AppTooltip text="Enter the full requirements and skills for the role" isDarkMode={isDarkMode}>
                  <HighlightedTextArea 
                    isDarkMode={isDarkMode}
                    placeholder="Paste Job Description here or use Voice Input..."
                    value={jdText || selectedMission?.jdText || ''}
                    onChange={(val) => setJdText(val)}
                    onKeyDown={(e) => {
                      if (e.ctrlKey && e.key === 'Enter') handleAnalyze();
                    }}
                  />
                </AppTooltip>
                <AppTooltip text="Voice-to-text input" isDarkMode={isDarkMode}>
                  <button 
                    onClick={() => startVoiceInput('jd')}
                    className="absolute bottom-4 right-4 p-2 rounded-full bg-indigo-600 text-white hover:bg-indigo-700 transition-all opacity-0 group-hover:opacity-100 shadow-lg shadow-indigo-500/20"
                  >
                    <Mic className="w-4 h-4" />
                  </button>
                </AppTooltip>
              </div>
              
              <div className="flex items-center gap-4">
                <FileUploadButton 
                  onChange={(e) => handleFileUpload(e, 'jd')} 
                  label="Upload JD (PDF/DOCX)" 
                  isDarkMode={isDarkMode}
                />
                <AppTooltip text="Use a sample job description" isDarkMode={isDarkMode}>
                  <button 
                    onClick={() => {
                      setJdText("Senior React Developer\n- 5+ years experience\n- React, Redux, Node.js\n- Experience with AWS and CI/CD pipelines\n- Strong communication skills");
                    }}
                    className={cn(
                      "px-4 py-2 rounded-lg text-sm font-medium border transition-all",
                      isDarkMode ? "border-white/10 hover:bg-white/5 text-gray-400" : "border-gray-200 hover:bg-gray-50 text-gray-600"
                    )}
                  >
                    Sample Data
                  </button>
                </AppTooltip>
              </div>
            </div>
          </SectionContainer>

          {/* Candidate Profile Input */}
          <SectionContainer title="Candidate Profile" icon={<User className="w-5 h-5" />} isDarkMode={isDarkMode}>
            <div className="space-y-4">
              <AppTooltip text="Paste CV content or candidate summary for analysis" isDarkMode={isDarkMode}>
                <HighlightedTextArea 
                  isDarkMode={isDarkMode}
                  placeholder="Paste Candidate CV or Profile content here..."
                  value={candidateText}
                  onChange={(val) => setCandidateText(val)}
                  onKeyDown={(e) => {
                    if (e.ctrlKey && e.key === 'Enter') handleAnalyze();
                  }}
                />
              </AppTooltip>
              
              <div className="flex items-center gap-4">
                <FileUploadButton 
                  onChange={(e) => handleFileUpload(e, 'candidate')} 
                  label="Upload CV (PDF/DOCX)" 
                  isDarkMode={isDarkMode}
                />
                <AppTooltip text="Use a sample candidate profile" isDarkMode={isDarkMode}>
                  <button 
                    onClick={() => {
                      setCandidateText("Alex Mercer\nfrontend developer with 4 years. Tech: React, Vue, Javascript, AWS cloud practitioner. missing Docker/K8s but eager to learn.");
                    }}
                    className={cn(
                      "px-4 py-2 rounded-lg text-sm font-medium border transition-all",
                      isDarkMode ? "border-white/10 hover:bg-white/5 text-gray-400" : "border-gray-200 hover:bg-gray-100 text-gray-600"
                    )}
                  >
                    Sample Data
                  </button>
                </AppTooltip>
              </div>
            </div>
          </SectionContainer>
        </div>

        {/* Analyze Button */}
        <div className="flex justify-center mb-12">
            <button 
              disabled={isLoading}
              onClick={handleAnalyze}
              className={cn(
                "group relative px-12 py-5 rounded-lg font-bold text-xs uppercase tracking-[0.2em] overflow-hidden transition-all active:scale-95 disabled:opacity-50",
                "bg-indigo-600 text-white shadow-[0_10px_30px_rgba(79,70,229,0.3)] shadow-indigo-500/20"
              )}
            >
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              <div className="relative flex items-center gap-3">
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Zap className="w-4 h-4" />
                )}
                {isLoading ? 'Processing Neural Engine...' : 'Analyze Candidate (Ctrl+Enter)'}
              </div>
            </button>
          </div>

        {/* Results Sections */}
        <AnimatePresence>
          {result && (
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
            <div className={cn(
              "flex flex-col sm:flex-row items-center justify-between p-6 rounded-3xl border mb-8",
              isDarkMode ? "bg-white/5 border-white/10 shadow-xl shadow-black/20" : "bg-white border-gray-200 shadow-xl"
            )}>
              <div className="flex items-center gap-4 mb-4 sm:mb-0">
                <div className="w-12 h-12 bg-[#D4AF37] rounded-2xl flex items-center justify-center font-bold text-[#0a0e27] text-2xl shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                  {result.matchScore}%
                </div>
                <div>
                  <h3 className="text-xl font-bold">{result.candidateName}</h3>
                  <p className="text-xs text-gray-400 uppercase tracking-widest">{result.jobTitle}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {selectedMission && (
                  <button 
                    onClick={resetAnalysis}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-sm transition-all shadow-lg shadow-indigo-500/20"
                  >
                    <Plus className="w-4 h-4" /> Analyze Next Candidate
                  </button>
                )}
                <button 
                  onClick={() => setResult(null)}
                  className={cn(
                    "px-6 py-3 rounded-xl font-bold text-sm transition-all border",
                    isDarkMode ? "border-white/10 hover:bg-white/5" : "border-gray-200 hover:bg-gray-50"
                  )}
                >
                  Edit Inputs
                </button>
              </div>
            </div>

            {/* Top Row: Score Gauge & Radar & Domain */}
            <div className="grid md:grid-cols-3 gap-8">
                <div className={cn(
                  "p-8 rounded-3xl border backdrop-blur-xl flex flex-col items-center justify-center text-center",
                  isDarkMode ? "bg-white/5 border-white/10 shadow-xl shadow-black/20" : "bg-white border-gray-200 shadow-xl"
                )}>
                  <MatchGauge score={result.matchScore} isDarkMode={isDarkMode} />
                  <div className="mt-6">
                    <h3 className="text-xl font-bold">{result.candidateName || 'Unknown Talent'}</h3>
                    <p className="text-blue-500 font-medium">Match Integrity Score</p>
                  </div>
                </div>

                <div className={cn(
                  "p-8 rounded-3xl border backdrop-blur-xl",
                  isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200"
                )}>
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-6">Skill Balance (AI vs Market)</h3>
                  <div className="h-64">
                    <Radar 
                      data={{
                        labels: result.skillsRadar.labels,
                        datasets: [
                          {
                            label: 'Candidate',
                            data: result.skillsRadar.candidate,
                            backgroundColor: 'rgba(79, 70, 229, 0.2)',
                            borderColor: '#4f46e5',
                            borderWidth: 2,
                          },
                          {
                            label: 'Market Baseline',
                            data: result.skillsRadar.market,
                            backgroundColor: 'rgba(99, 102, 241, 0.1)',
                            borderColor: 'rgba(99, 102, 241, 0.5)',
                            borderWidth: 1,
                            borderDash: [5, 5],
                          }
                        ]
                      }}
                      options={{
                        scales: {
                          r: {
                            angleLines: { color: isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' },
                            grid: { color: isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' },
                            pointLabels: { color: isDarkMode ? '#9ca3af' : '#4b5563', font: { size: 10 } },
                            ticks: { display: false }
                          }
                        },
                        plugins: { legend: { display: false } }
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className={cn(
                    "p-6 rounded-2xl border flex items-center gap-4",
                    isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm"
                  )}>
                    <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
                      <LayoutDashboard className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-xs text-blue-400 uppercase tracking-widest font-bold">IT Domain</h4>
                      <p className="font-bold text-lg text-blue-600">{result.itDomain}</p>
                    </div>
                  </div>
                  
                  <div className={cn(
                    "p-6 rounded-2xl border flex items-center gap-4",
                    isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-blue-100 shadow-sm"
                  )}>
                    <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-500">
                      <Zap className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-xs text-indigo-400 uppercase tracking-widest font-bold">Score benchmark</h4>
                      <p className="font-bold text-lg text-indigo-500">{result.salaryBenchmark}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <AppTooltip text="Export analysis to PDF" isDarkMode={isDarkMode}>
                      <button 
                        onClick={downloadPDF}
                        className="w-full flex flex-col items-center justify-center gap-2 p-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white transition-all shadow-lg shadow-indigo-500/20 active:scale-95"
                      >
                        <Download className="w-5 h-5" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Export PDF</span>
                      </button>
                    </AppTooltip>
                    
                    <AppTooltip text="Search deep market web insights" isDarkMode={isDarkMode}>
                      <button 
                        onClick={openDeepSearch}
                        className={cn(
                          "w-full flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border transition-all active:scale-95",
                          isDarkMode ? "hover:bg-white/5 border-white/10" : "hover:bg-blue-50 border-blue-100 text-blue-400"
                        )}
                      >
                        <Search className="w-5 h-5" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Deep Search</span>
                      </button>
                    </AppTooltip>

                    <AppTooltip text="Download analysis as CSV" isDarkMode={isDarkMode}>
                      <button 
                        onClick={exportCSV}
                        className={cn(
                          "w-full flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border transition-all active:scale-95",
                          isDarkMode ? "hover:bg-white/5 border-white/10" : "hover:bg-blue-50 border-blue-100 text-blue-400"
                        )}
                      >
                        <Download className="w-5 h-5" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Export CSV</span>
                      </button>
                    </AppTooltip>

                    <AppTooltip text="Launch scheduling calendar" isDarkMode={isDarkMode}>
                      <button 
                        onClick={scheduleInterview}
                        className="w-full flex flex-col items-center justify-center gap-2 p-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white transition-all shadow-lg shadow-blue-500/20 active:scale-95"
                      >
                        <Zap className="w-5 h-5" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Schedule</span>
                      </button>
                    </AppTooltip>
                  </div>
                </div>
              </div>

              {/* Score History Graph */}
              {history.length > 1 && (
                <div className={cn(
                  "p-8 rounded-3xl border backdrop-blur-xl",
                  isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200"
                )}>
                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-6">Performance Trend (last {history.length} analyses)</h3>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={[...history].reverse()}>
                        <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"} />
                        <XAxis hide dataKey="timestamp" />
                        <YAxis stroke="#4b5563" fontSize={12} />
                        <RechartsTooltip 
                          contentStyle={{ 
                            backgroundColor: isDarkMode ? '#0d122d' : '#fff', 
                            borderColor: isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                            borderRadius: '12px'
                          }} 
                        />
                        <Line type="monotone" dataKey="matchScore" stroke="#4f46e5" strokeWidth={3} dot={{ fill: '#4f46e5' }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* Red Flag Banner */}
              {result.redFlags.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl flex items-center gap-3 text-red-500 shadow-sm"
                >
                  <AlertTriangle className="w-6 h-6 shrink-0" />
                  <div>
                    <span className="font-bold uppercase tracking-tight mr-2 underline">RECRUITMENT RED ALERT:</span>
                    <span className="text-sm font-medium italic">{result.redFlags.join(' • ')}</span>
                  </div>
                </motion.div>
              )}

              {/* Detailed Lists */}
              <div className="grid md:grid-cols-2 gap-8">
                <InfoCard 
                  title="Strong Match Alignment" 
                  items={result.strongMatches} 
                  icon={<CheckCircle2 className="w-5 h-5 text-green-500" />} 
                  isDarkMode={isDarkMode} 
                />
                <InfoCard 
                  title="Critical Gaps Detected" 
                  items={result.missingImportant} 
                  icon={<AlertTriangle className="w-5 h-5 text-orange-500" />} 
                  isDarkMode={isDarkMode} 
                />
                <InfoCard 
                  title="Hidden Stack (Inferred)" 
                  items={result.hiddenStack} 
                  icon={<Zap className="w-5 h-5 text-indigo-500" />} 
                  isDarkMode={isDarkMode} 
                />
                <InfoCard 
                  title="Interview Strategy" 
                  items={result.interviewQuestions} 
                  icon={<MessageSquare className="w-5 h-5 text-purple-500" />} 
                  isDarkMode={isDarkMode} 
                />
              </div>

              {/* Advanced Features Row */}
              <div className="grid md:grid-cols-2 gap-8">
                <SectionContainer title="Verification Points" icon={<Zap className="w-5 h-5" />} isDarkMode={isDarkMode}>
                  <div className="space-y-4">
                    {result.flouPoints.map((p, i) => (
                      <div key={i} className={cn(
                        "p-4 rounded-xl border",
                        isDarkMode ? "bg-black/20 border-white/5" : "bg-blue-50 border-blue-100 shadow-sm"
                      )}>
                        <p className="text-sm font-bold text-blue-600 mb-1">Verify: {p.question}</p>
                        <p className="text-xs text-blue-400">Reason: {p.reason}</p>
                      </div>
                    ))}
                  </div>
                </SectionContainer>

                <SectionContainer title="LinkedIn Recruiter Boolean" icon={<Search className="w-5 h-5" />} isDarkMode={isDarkMode}>
                  <div className={cn(
                    "p-4 rounded-xl border relative font-mono text-sm break-all",
                    isDarkMode ? "bg-black/40 border-white/10 text-gray-300" : "bg-gray-100 border-gray-200 text-gray-700"
                  )}>
                    {result.booleanString}
                    <AppTooltip text="Copy search string to clipboard" isDarkMode={isDarkMode}>
                      <button 
                        onClick={() => copyToClipboard(result.booleanString)}
                        className="absolute top-2 right-2 p-2 hover:bg-white/10 rounded-lg transition-all"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </AppTooltip>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-2 italic">* Generated automatically from JD skills analysis.</p>
                </SectionContainer>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
          </div>
        )}
      </main>

      {/* History Sidebar */}
      <AnimatePresence>
        {showHistory && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHistory(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className={cn(
                "fixed top-0 right-0 h-full w-full max-w-sm z-[70] p-6 border-l shadow-2xl overflow-hidden flex flex-col",
                isDarkMode ? "bg-[#0d122d] border-white/10" : "bg-white border-blue-100"
              )}
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bold flex items-center gap-2 text-indigo-600">
                  <Zap className="w-5 h-5" />
                  Analysis History
                </h3>
                <button onClick={() => setShowHistory(false)} className="p-2 hover:bg-gray-100 rounded-lg text-gray-400">
                  <Plus className="w-6 h-6 rotate-45" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-gray-200">
                {history.map((item) => (
                  <div 
                    key={item.id}
                    className={cn(
                      "p-4 rounded-xl border group transition-all cursor-pointer relative",
                      isDarkMode ? "hover:bg-white/5 border-white/5" : "hover:bg-blue-50 border-blue-100 bg-white"
                    )}
                    onClick={() => loadFromHistory(item)}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-[10px] text-gray-400 font-mono font-bold uppercase">
                        {new Date(item.timestamp).toLocaleDateString()}
                      </span>
                      <span className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded",
                        item.matchScore > 80 ? "bg-green-500/10 text-green-500" : 
                        item.matchScore > 50 ? "bg-indigo-500/10 text-indigo-500" : "bg-red-500/10 text-red-500"
                      )}>
                        {item.matchScore}%
                      </span>
                    </div>
                    <h4 className={cn(
                      "font-bold text-sm truncate pr-6",
                      isDarkMode ? "text-gray-200" : "text-gray-800"
                    )}>{item.candidateName}</h4>
                    <p className="text-xs text-gray-500 truncate font-medium">{item.jobTitle}</p>
                    
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteHistoryItem(item.id);
                      }}
                      className="absolute right-4 bottom-4 p-2 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                {history.length === 0 && (
                  <div className="text-center py-12 text-gray-400 italic font-medium">
                    <p>No analysis history yet.</p>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <footer className={cn(
        "py-12 border-t text-center px-6 mt-12",
        isDarkMode ? "bg-black/20 border-white/5 text-gray-500" : "bg-gray-50 border-gray-100 text-gray-400"
      )}>
        <p className="text-sm font-bold uppercase tracking-widest text-slate-500">FAEZSA Talent Analyzer • Professional IT Recruitment Intelligence</p>
        <p className="text-[10px] mt-2 font-mono uppercase tracking-[0.2em] opacity-60">AI Integrated Neural Engine • Protected Enterprise Grade</p>
      </footer>

      {/* API Key Prompt */}
      <AnimatePresence>
        {showApiKeyPrompt && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowApiKeyPrompt(false)}
              className="absolute inset-0 bg-[#0a0e27]/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className={cn(
                "relative w-full max-w-md p-8 rounded-3xl border shadow-2xl overflow-hidden",
                isDarkMode ? "bg-[#0d122d] border-white/10" : "bg-white border-gray-200"
              )}
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-500" />
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-indigo-600">
                <Zap className="w-6 h-6 text-indigo-500" />
                Intelligence Settings
              </h3>
              <p className="text-sm text-gray-500 mb-6">
                To use Real-Time AI Analysis, provide your Gemini API key. 
                Get a free key from <a href="https://aistudio.google.com/app/apikey" target="_blank" className="text-indigo-600 underline">aistudio.google.com</a>.
                If left empty, <span className="text-indigo-600 font-bold">Mock Mode</span> will be used.
              </p>
              
              <div className="space-y-4">
                <AppTooltip text="Enter your Google Gemini API key to enable neuro-analysis" isDarkMode={isDarkMode}>
                  <input 
                    type="password"
                    placeholder="Paste AI key here..."
                    className={cn(
                      "w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-mono text-sm",
                      isDarkMode ? "bg-black/20 border-white/10 text-gray-200" : "bg-gray-50 border-gray-200 text-gray-800 shadow-inner"
                    )}
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                </AppTooltip>
                <div className="flex gap-3">
                  <button 
                    onClick={() => saveApiKey(apiKey)}
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-indigo-500/20 active:scale-95 transition-all"
                  >
                    Save Key
                  </button>
                  <button 
                    onClick={() => saveApiKey('')}
                    className={cn(
                      "flex-1 font-bold py-3 rounded-xl border transition-all active:scale-95",
                      isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-gray-200 hover:bg-gray-50 text-gray-600"
                    )}
                  >
                    Use Mock Mode
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Compare Mode */}
      <AnimatePresence>
        {showQuickCompare && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowQuickCompare(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className={cn(
                "relative w-full max-w-2xl p-8 rounded-3xl border shadow-2xl overflow-hidden",
                isDarkMode ? "bg-[#0d122d] border-white/10" : "bg-white border-gray-200"
              )}
            >
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <Search className="w-6 h-6 text-indigo-400" />
                Quick Compare Mode
              </h2>
              
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Select Profile A</label>
                  <select 
                    className={cn(
                      "w-full p-3 rounded-xl border appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500",
                      isDarkMode ? "bg-black/20 border-white/10" : "bg-gray-50 border-gray-200 text-gray-800"
                    )}
                    value={compareSelection.id1}
                    onChange={(e) => setCompareSelection({ ...compareSelection, id1: e.target.value })}
                  >
                    <option value="">Select Candidate...</option>
                    {history.map(h => <option key={h.id} value={h.id}>{h.candidateName} ({h.matchScore}%)</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold text-gray-500 tracking-widest">Select Profile B</label>
                  <select 
                    className={cn(
                      "w-full p-3 rounded-xl border appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500",
                      isDarkMode ? "bg-black/20 border-white/10" : "bg-gray-50 border-gray-200 text-gray-800"
                    )}
                    value={compareSelection.id2}
                    onChange={(e) => setCompareSelection({ ...compareSelection, id2: e.target.value })}
                  >
                    <option value="">Select Candidate...</option>
                    {history.map(h => <option key={h.id} value={h.id}>{h.candidateName} ({h.matchScore}%)</option>)}
                  </select>
                </div>
              </div>

              {compareSelection.id1 && compareSelection.id2 && (
                <div className="grid grid-cols-2 gap-8 mb-8 border-t border-dashed border-white/10 pt-8">
                  {[compareSelection.id1, compareSelection.id2].map((id, i) => {
                    const item = history.find(h => h.id === id);
                    if (!item) return null;
                    return (
                      <div key={id} className="text-center">
                        <div className={cn(
                          "text-4xl font-mono font-bold mb-2",
                          item.matchScore > 80 ? "text-[#D4AF37]" : "text-indigo-400"
                        )}>{item.matchScore}%</div>
                        <h4 className="font-bold mb-4 text-sm uppercase tracking-tight">{item.candidateName}</h4>
                        
                        <div className="space-y-4">
                          <div>
                            <div className="text-[9px] uppercase font-bold text-gray-500 mb-2">Key Strengths</div>
                            <div className="flex flex-wrap gap-1 justify-center">
                              {item.result.strongMatches.slice(0, 3).map(s => (
                                <span key={s} className="text-[9px] bg-green-500/10 text-green-400 px-2 py-1 rounded border border-green-500/20">{s}</span>
                              ))}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] uppercase font-bold text-gray-500 mb-2">Critical Gaps</div>
                            <div className="flex flex-wrap gap-1 justify-center">
                              {item.result.missingImportant.slice(0, 3).map(s => (
                                <span key={s} className="text-[9px] bg-red-500/10 text-red-400 px-2 py-1 rounded border border-red-500/20">{s}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="flex justify-between items-center bg-white/5 py-4 px-6 -mx-8 -mb-8 mt-8 border-t border-white/10">
                <span className="text-[10px] text-gray-500 italic">Select two history items to compare key metrics side-by-side.</span>
                <button 
                  onClick={() => setShowQuickCompare(false)}
                  className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded font-bold text-xs uppercase tracking-widest"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Sub-components
function SectionContainer({ title, icon, children, isDarkMode }: { title: string, icon: React.ReactNode, children: React.ReactNode, isDarkMode: boolean }) {
  return (
    <div className={cn(
      "p-6 rounded-3xl border backdrop-blur-xl",
      isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200"
    )}>
      <div className="flex items-center gap-3 mb-6">
        <div className="text-blue-500">{icon}</div>
        <h3 className="font-bold uppercase tracking-widest text-xs text-gray-400">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function InfoCard({ title, items, icon, isDarkMode }: { title: string, items: string[], icon: React.ReactNode, isDarkMode: boolean }) {
  return (
    <div className={cn(
      "p-6 rounded-2xl border",
      isDarkMode ? "bg-white/5 border-white/5" : "bg-white border-gray-200"
    )}>
      <div className="flex items-center gap-2 mb-4">
        {icon}
        <h4 className="font-bold text-sm tracking-tight">{title}</h4>
      </div>
      <ul className="space-y-2">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
            <span className="text-blue-500 mt-1">•</span>
            {item}
          </li>
        ))}
        {items.length === 0 && <li className="text-xs text-gray-500 italic">No data detected.</li>}
      </ul>
    </div>
  );
}

function MatchGauge({ score, isDarkMode }: { score: number, isDarkMode: boolean }) {
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const color = 
    score >= 90 ? '#D4AF37' : 
    score >= 70 ? '#6366f1' : 
    score >= 40 ? '#f97316' : 
    '#ef4444';

  return (
    <div className="relative w-40 h-40 flex items-center justify-center">
      <svg className="w-full h-full transform -rotate-90">
        <circle
          cx="80"
          cy="80"
          r={radius}
          stroke={isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}
          strokeWidth="8"
          fill="transparent"
        />
        <motion.circle
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          cx="80"
          cy="80"
          r={radius}
          stroke={color}
          strokeWidth="8"
          strokeDasharray={circumference}
          fill="transparent"
          strokeLinecap="round"
          className={cn(score >= 90 && "drop-shadow-[0_0_12px_#D4AF37]")}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-mono font-bold">{score}</span>
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter opacity-60">Match %</span>
      </div>
    </div>
  );
}

function FileUploadButton({ onChange, label, isDarkMode }: { onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, label: string, isDarkMode: boolean }) {
  return (
    <AppTooltip text={`Upload ${label.toLowerCase()}`} isDarkMode={isDarkMode}>
      <label className={cn(
        "flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border cursor-pointer transition-all active:scale-[0.98]",
        isDarkMode ? "border-white/10 hover:bg-white/5 text-gray-300" : "border-gray-200 hover:bg-gray-50 text-gray-600"
      )}>
        <Plus className="w-4 h-4" />
        {label}
        <input type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={onChange} />
      </label>
    </AppTooltip>
  );
}


import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

const SKILLS_DATABASE = [
  'Python', 'Java', 'JavaScript', 'React', 'AWS', 'Docker', 'Kubernetes', 'SQL', 
  'MongoDB', 'CI/CD', 'Terraform', 'GraphQL', 'Node.js', 'TypeScript', 'Django', 
  'Spring Boot', 'Angular', 'Vue', 'Azure', 'GCP', 'Jenkins', 'Git', 'Linux', 
  'Redis', 'Kafka', 'Figma', 'System Design', 'Microservices', 'Unit Testing'
];

function extractSkills(text: string): string[] {
  const found: string[] = [];
  const lowerText = text.toLowerCase();
  SKILLS_DATABASE.forEach(skill => {
    if (lowerText.includes(skill.toLowerCase())) {
      found.push(skill);
    }
  });
  return found;
}

function detectDomain(skills: string[]): string {
  const domains = {
    'Frontend Ecosystem': ['React', 'Vue', 'Angular', 'JavaScript', 'TypeScript', 'Figma'],
    'Backend Arch': ['Java', 'Python', 'Node.js', 'Django', 'Spring Boot', 'SQL', 'MongoDB'],
    'Cloud & DevOps': ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Jenkins', 'Terraform', 'Azure', 'GCP'],
    'Data Infrastructure': ['SQL', 'MongoDB', 'Kafka', 'Redis', 'Python']
  };

  let bestDomain = 'General IT';
  let maxCount = 0;

  Object.entries(domains).forEach(([domain, keywords]) => {
    const count = keywords.filter(k => skills.includes(k)).length;
    if (count > maxCount) {
      maxCount = count;
      bestDomain = domain;
    }
  });

  return bestDomain;
}

export interface JdMetadata {
  jobTitle: string;
  requiredSkills: string[];
  experienceLevel: string;
}

export async function extractJdMetadata(text: string, apiKey?: string): Promise<JdMetadata> {
  if (!text.trim()) {
    return { jobTitle: '', requiredSkills: [], experienceLevel: '' };
  }

  const useMock = !apiKey && !process.env.GEMINI_API_KEY;

  if (useMock) {
    return mockExtractJdMetadata(text);
  }

  const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY || "" });
  const prompt = `
    Extract key information from the following Job Description (JD) text.
    Return only a JSON object with:
    - "jobTitle": The official title of the role.
    - "requiredSkills": A list of the top 5-7 critical technical skills mentioned.
    - "experienceLevel": One of [Junior, Mid-Level, Senior, Lead, Staff, Principal, Not Specified].
    
    JD Text:
    ${text}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const data = JSON.parse(response.text);
    return {
      jobTitle: data.jobTitle || "Not found",
      requiredSkills: data.requiredSkills || [],
      experienceLevel: data.experienceLevel || "Not specified"
    };
  } catch (error) {
    console.warn("Gemini extraction failed, falling back to mock", error);
    return mockExtractJdMetadata(text);
  }
}

function mockExtractJdMetadata(text: string): JdMetadata {
  const lines = text.split('\n').filter(l => l.trim().length > 0);
  const firstLine = lines[0] || "";
  
  // Try to find a title in the first few lines
  let jobTitle = firstLine.slice(0, 50);
  if (jobTitle.length < 5) jobTitle = "Potential Role Identified";

  const requiredSkills = extractSkills(text).slice(0, 6);
  
  let experienceLevel = "Not specified";
  const lowerText = text.toLowerCase();
  if (/\b(senior|lead|staff|principal|head of|manager)\b/i.test(lowerText)) experienceLevel = "Senior/Lead";
  else if (/\b(junior|entry|intern|graduate)\b/i.test(lowerText)) experienceLevel = "Junior";
  else if (/\b(mid|intermediate|experienced|years of)\b/i.test(lowerText)) experienceLevel = "Mid-Level";

  return { jobTitle, requiredSkills, experienceLevel };
}

export async function analyzeTalent(jdText: string, candidateText: string, apiKey?: string): Promise<AnalysisResult> {
  const useMock = !apiKey && !process.env.GEMINI_API_KEY;

  if (useMock) {
    return mockAnalyze(jdText, candidateText);
  }

  const ai = new GoogleGenAI({ apiKey: apiKey || process.env.GEMINI_API_KEY || "" });
  const prompt = `
    Analyze the following Job Description (JD) and Candidate Profile.
    Perform a deep IT recruitment evaluation.
    
    JD:
    ${jdText}
    
    Candidate:
    ${candidateText}
    
    Output the result in JSON format following this exact structure:
    {
      "jobTitle": "Extracted job title from JD",
      "candidateName": "Extracted candidate name",
      "matchScore": number (0-100),
      "itDomain": "e.g. Frontend Development, DevOps, AI Engineering",
      "summary": "Brief professional summary of the match",
      "strongMatches": ["skill/experience 1", "..."],
      "missingImportant": ["skill 1", "..."],
      "redFlags": ["reason 1", "..."],
      "plusPoints": ["reason 1", "..."],
      "flouPoints": [{"question": "Verification question", "reason": "Why this is unclear"}],
      "hiddenStack": ["Technologies likely used but not explicitly mentioned"],
      "interviewQuestions": ["Question 1", "..."],
      "salaryBenchmark": "Estimated range (e.g. $80k - $110k)",
      "booleanString": "LinkedIn recruiter boolean string based on JD key skills",
      "skillsRadar": {
        "labels": ["Technical Proficiency", "Experience Level", "Soft Skills", "Domain Knowledge", "Tooling", "Problem Solving"],
        "candidate": [value 1-10, ...],
        "market": [value 1-10, ...]
      }
    }
  `;

  // ... (rest of the Gemini logic)
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json"
    }
  });

  const rawJson = response.text;
  const result = JSON.parse(rawJson);
  
  return {
    ...result,
    sourceJd: jdText,
    sourceCandidate: candidateText,
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now()
  };
}

export function mockAnalyze(jdText: string, candidateText: string): AnalysisResult {
  const jdSkills = extractSkills(jdText);
  const candSkills = extractSkills(candidateText);
  
  const matches = candSkills.filter(s => jdSkills.includes(s));
  const missing = jdSkills.filter(s => !candSkills.includes(s));
  const plus = candSkills.filter(s => !jdSkills.includes(s));
  
  const score = jdSkills.length > 0 ? Math.round((matches.length / jdSkills.length) * 100) : 50;
  const itDomain = detectDomain(jdSkills);

  const flouWords = ['familiar', 'basic', 'some experience', 'exposure'];
  const flouPoints = flouWords
    .filter(word => candidateText.toLowerCase().includes(word))
    .map(word => ({
      question: `Clarify level of expertise in skills described as "${word}"`,
      reason: `User used cautious wording "${word}" which may signal lack of depth.`
    }));

  const hiddenStack: string[] = [];
  if (jdText.toLowerCase().includes('microservices')) hiddenStack.push('Docker', 'Kubernetes', 'gRPC');
  if (jdText.toLowerCase().includes('frontend')) hiddenStack.push('Webpack', 'Babel', 'CI/CD');

  const questions = missing.length > 0 
    ? missing.slice(0, 3).map(m => `How would you handle a project requiring ${m} given your current profile?`)
    : ["Can you describe your most challenging architectural decision?"];

  return {
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
    sourceJd: jdText,
    sourceCandidate: candidateText,
    jobTitle: jdText.split('\n')[0].slice(0, 50) || "IT Role",
    candidateName: candidateText.split('\n')[0].slice(0, 50) || "Tech Talent",
    matchScore: score,
    itDomain: itDomain,
    summary: `Candidate has ${matches.length} of ${jdSkills.length} required skills. ${score > 70 ? 'Strong alignment for the role.' : 'Partial match, needs verification on missing stack.'}`,
    strongMatches: matches,
    missingImportant: missing,
    redFlags: score < 30 ? ["Low overall skill alignment (<30%)"] : [],
    plusPoints: plus,
    flouPoints: flouPoints,
    hiddenStack: hiddenStack,
    interviewQuestions: questions,
    salaryBenchmark: "$95k - $125k (Based on domain trends)",
    booleanString: `("${matches.slice(0,3).join('" OR "')}") AND ("${missing.slice(0,2).join('" OR "')}")`,
    skillsRadar: {
      labels: ["Technical", "Experience", "Soft Skills", "Domain", "Tooling", "Problem Solving"],
      candidate: [
        matches.length > 3 ? 8 : 5,
        candidateText.length > 500 ? 9 : 4,
        7,
        matches.includes('AWS') ? 9 : 6,
        candSkills.length > 5 ? 8 : 5,
        7
      ],
      market: [8, 7, 8, 8, 7, 8]
    }
  };
}
